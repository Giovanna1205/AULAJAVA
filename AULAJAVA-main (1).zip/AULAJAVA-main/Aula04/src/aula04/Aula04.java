
package aula04;

/**
 *
 * @author giovanna
 */
public class Aula04 {

    
    public static void main(String[] args) {
        System.out.println("O valor de pi é:"+ Math.PI);
        System.out.println("O máximo é:"+ Math.max(5,10));
        System.out.println("O mínimo é:"+ Math.min(5,10));
        System.out.println("O raiz quadrada é:"+ Math.sqrt(64));
        
       
        System.out.println("Exponencial e potenciação \n");
        System.out.println("O valor de E é:"+ Math.E+ "\n\n");
        System.out.println("'e' elevado ao quadrado="+ Math.exp(2));
        System.out.println("2 elevado"+ Math.pow(2,3));
    }
    
}
