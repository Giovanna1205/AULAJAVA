
package aula08;

/**
 *
 * @author Giovanna
 */
public class Aula08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a=10;
        int b=5;
        System.out.println("a > b && a < b");
        if (a > b) {
            System.out.println("Maior");
        }else if{
            System.out.println("Menor");
            }else{
            System.out.println("igual");
        }
        
    }
    
}
