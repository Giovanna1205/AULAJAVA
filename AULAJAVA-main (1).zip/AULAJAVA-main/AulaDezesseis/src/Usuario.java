/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 17932453631
 */
public class Usuario {
    private String usuario="giovanna";
            private String senha="123";
            
            public String getUsuario() {
                return usuario;
            }
    public void setUsuario(String usuario){
        this.usuario=usuario;
    }
    public String getSenha(){
        return senha;
    }
    public void setSenha(String senha){
        this.senha=senha;
    }
}
