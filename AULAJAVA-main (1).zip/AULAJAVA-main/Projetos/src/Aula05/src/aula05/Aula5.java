
package aula05;

/**
 *
 * @author giovanna
 */
public class Aula5 {
    

public static void main (String[]args) {
int a=10;
String b="10";
int c=2;
String d="10";
int resultadoA=a+c;
int resultadoB=a-c;
int resultadoC=a*c;
int resultadoD=a/c;
int resultadoE=a%c;
int resultadoF=(int)a/c;
System.out.println(resultadoA);
System.out.println(resultadoB);
System.out.println(resultadoC);
System.out.println(resultadoD);
System.out.println(resultadoE);
System.out.println(resultadoF);
}
}