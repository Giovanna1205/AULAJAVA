package aulaex1;
/**
 * Exercício 01
 * Aula:10/07/2023
 * Disciplina: Linguagem de Programação
 * Download Kit Java SE:https://www.oracle.com/br/java/technologies/downloads/#jdk20-windows
 * Download NetBeans:https://netbeans.apache.org/download/index.html 
 * @author Giovanna de Almeida
 */
public class aula01 {
    public static void main(String[] args) {
        System.out.println("Ola Mundo");
    }
    
}