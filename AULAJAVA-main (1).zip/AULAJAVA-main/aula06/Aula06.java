/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula06;

/**
 *
 * @author giovanna
 */
public class Aula06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float n1=5,n2=8,n3=10,n4=9;
        float soma=n1+n2+n3+n4;
        float media=soma/4;
        System.out.print ("A média entre as notas é:"+media);
                
      
        
        
        
        
        
        
    }
        
    }
    
}
